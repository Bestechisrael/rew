<!DOCTYPE html>
<!--[if IE 6]>
<html id="ie6" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 7]>
<html id="ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html id="ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 6) | !(IE 7) | !(IE 8)  ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
    
	<?php //elegant_description(); ?>
	<?php //elegant_keywords(); ?>
	<?php //elegant_canonical(); ?>

	<?php //do_action( 'et_head_meta' ); ?>

	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

	<?php $template_directory_uri = get_template_directory_uri(); ?>
	<!--[if lt IE 9]>
	<script src="<?php echo esc_url( $template_directory_uri . '/js/html5.js"' ); ?>" type="text/javascript"></script>
	<![endif]-->
    <link type="text/css" rel="stylesheet" href="<?=get_stylesheet_directory_uri();?>/css/bootstrap.min.css"/>
<link type="text/css" rel="stylesheet" href="<?=get_stylesheet_directory_uri();?>/css/font-awesome.min.css"/>
<link type="text/css" rel="stylesheet" href="<?=get_stylesheet_directory_uri();?>/style.css"/>
<link type="text/css" rel="stylesheet" href="<?=get_stylesheet_directory_uri();?>/css/responsive.css"/>


	<script type="text/javascript">
		//document.documentElement.className = 'js';
	</script>

	<?php wp_head(); ?>
<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i" rel="stylesheet">

</head>
<body>
<div id="wapper">
<header id="header">
   <section class="mainmenu-area stricky">
    <div class="container">
    
     <div class="row mobile-header"> 
          
         <div class="col-lg-4 col-sm-4 col-xs-4">   <nav class="navbar navbar-default" role="navigation">
            
            
              <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                
               
                
             
              
              
      
          </div>
          </nav> </div> 
         <div class="col-lg-4 col-sm-4 col-xs-4"> 
         <div class="logo-block">
         <?php
				$logo = ( $user_logo = et_get_option( 'divi_logo' ) ) && '' != $user_logo
					? $user_logo
					: $template_directory_uri . '/images/logo.png';
			?>
        <!--<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>-->
       <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
						<img src="<?php echo esc_attr( $logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"    />
					</a>
            </div>  
          </div>
          <div class="col-lg-4 col-sm-4 col-xs-4"> <div class="search">
                      <!-- <input type="text" class="form-control input-sm" maxlength="64" placeholder="Search">-->
					    <a href="#" class="searchicon"><i class="fa fa-search" aria-hidden="true"></i> </a>
                  </div>  </div> 
                  
                   
     
     </div>
     
      <div class="row  desktop-header">
      
        <div class="col-lg-2">  <div class="logo-block">  <?php
				$logo = ( $user_logo = et_get_option( 'divi_logo' ) ) && '' != $user_logo
					? $user_logo
					: $template_directory_uri . '/images/logo.png';
			?>
        <!--<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>-->
       <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
						<img src="<?php echo esc_attr( $logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"  />
					</a>   </div> 
        </div>
        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
            <nav class="navbar navbar-default" role="navigation">
            
            
              <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                
              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
                <ul class="nav navbar-nav">
                   <?php  wp_nav_menu( array( 'theme_location' => 'primary-menu', 'container' => '', 'fallback_cb' => '', 'echo' => true, 'items_wrap' => '%3$s' ) ); ?>
                 <!-- <li class="dropdown">
                  
                  
                   <a class="active" href="#" class="dropdown-toggle" data-toggle="dropdown">PRODUCTS
                   <b class="caret"></b></a>
                    <ul class="dropdown-menu">
					  <li><a href="index.html">PRODUCTS-1</a></li>
                      <li><a href="products-2.html">PRODUCTS-2</a></li>
                      <li><a href="products-3.html">PRODUCTS-3</a></li>
                    </ul>
                  </li>
                  <li class="dropdown">
                   <a href="servuces-delivery.html" class="dropdown-toggle" data-toggle="dropdown">
                   SERVICRES & DELIVERY <b class="caret"></b></a>
                    <ul class="dropdown-menu">
					  <li><a href="servuces-delivery.html">SERVICRES & DELIVERY-1</a></li>
                      <li><a href="servuces-delivery-1.html">SERVICRES & DELIVERY-2</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  TOOLS & RESOURCES <b class="caret"></b></a>
                    <ul class="dropdown-menu">
					<li><a href="tools-resources-1.html">TOOLS & RESOURCES-1</a></li>
                      <li><a href="tools-resources-2.html">TOOLS & RESOURCES-2</a></li>
                      <li><a href="tools-resources-3.html">TOOLS & RESOURCES-3</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  LOCATIONS<b class="caret"></b></a>
                    <ul class="dropdown-menu">
					 <li><a href="locations-1.html">LOCATIONS-1</a></li>
                      <li><a href="locations-2.html">LOCATIONS-2</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  ABOUT REW<b class="caret"></b></a>
                    <ul class="dropdown-menu">
					   <li><a href="about-rew-1.html">ABOUT REW-1</a></li>
                      <li><a href="about-rew-2.html">ABOUT REW-2</a></li>
                      <li><a href="about-rew-3.html">ABOUT REW-3</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  CAREERS<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                      <li><a href="careers-1.html">CAREERS-1</a></li>
					   <li><a href="careers-2.html">CAREERS-2</a></li>
                    </ul>
                  </li>-->
				 

                  
                </ul>
              </div>
              
              
      
          </div>
          </nav>
        </div>
        <div class="col-lg-1">  <div class="search">
                      <!-- <input type="text" class="form-control input-sm" maxlength="64" placeholder="Search">-->
					    <a href="#" class="searchicon"><i class="fa fa-search" aria-hidden="true"></i> </a>
                  </div> </div>
      </div>
	     
    </div>
  </section>
  
  <div class="services-title">
  <div class="container">
  <div class="services-nation">
   
        <p class="desktop-header">SERVICES THE NATION</p>
        <ul class="desktop-header">
          <li ><a href="#">FIND MY LOCATION <i class="fa fa-map-marker" aria-hidden="true"></i></a></li>
          <li><a href="#">LOG IN</a></li>
        </ul>
        
          <ul class="mobile-header">
          <li ><a href="#"> <i class="fa fa-map-marker" aria-hidden="true"></i></a></li>
          <li><a href="#">LOG IN</a></li>
        </ul>
        
       </div> 
       
       
		</div>
      </div>
      
 <div class="container mobile-header"> 
  
  <div class="row">
  
 <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                  <li class="dropdown">
                   <a class="active" href="#" class="dropdown-toggle" data-toggle="dropdown">PRODUCTS
                   <b class="caret"></b></a>
                    <ul class="dropdown-menu">
					  <li><a href="index.html">PRODUCTS-1</a></li>
                      <li><a href="products-2.html">PRODUCTS-2</a></li>
                      <li><a href="products-3.html">PRODUCTS-3</a></li>
                    </ul>
                  </li>
                  <li class="dropdown">
                   <a href="servuces-delivery.html" class="dropdown-toggle" data-toggle="dropdown">
                   SERVICRES & DELIVERY <b class="caret"></b></a>
                    <ul class="dropdown-menu">
					  <li><a href="servuces-delivery.html">SERVICRES & DELIVERY-1</a></li>
                      <li><a href="servuces-delivery-1.html">SERVICRES & DELIVERY-2</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  TOOLS & RESOURCES <b class="caret"></b></a>
                    <ul class="dropdown-menu">
					<li><a href="tools-resources-1.html">TOOLS & RESOURCES-1</a></li>
                      <li><a href="tools-resources-2.html">TOOLS & RESOURCES-2</a></li>
                      <li><a href="tools-resources-3.html">TOOLS & RESOURCES-3</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  LOCATIONS<b class="caret"></b></a>
                    <ul class="dropdown-menu">
					 <li><a href="locations-1.html">LOCATIONS-1</a></li>
                      <li><a href="locations-2.html">LOCATIONS-2</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  ABOUT REW<b class="caret"></b></a>
                    <ul class="dropdown-menu">
					   <li><a href="about-rew-1.html">ABOUT REW-1</a></li>
                      <li><a href="about-rew-2.html">ABOUT REW-2</a></li>
                      <li><a href="about-rew-3.html">ABOUT REW-3</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  CAREERS<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                      <li><a href="careers-1.html">CAREERS-1</a></li>
					   <li><a href="careers-2.html">CAREERS-2</a></li>
                    </ul>
                  </li>
				 

                  
                </ul>
              </div>
  
  </div>
 </div>     
   
  </header>