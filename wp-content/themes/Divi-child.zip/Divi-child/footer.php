<div class="footer-img"> 
 </div>
<div class="footer-title">
  <div class="container">
    <div class="row">
        <div class="col-md-5 col-sm-5">
          <div class="footer">
            <h3>Rew Materials Corporate Offices</h3>
            <p>15720 w 108th St, suite 100<br>
              Lenexa, Ks 66219</p>
          </div>
          <?php //echo the_widget('sidebar-2');
		  	//dynamic_sidebar('sidebar-5');
		   ?>
        </div>
        <div class="col-md-7 col-sm-7">
          <div class="footer-right">
            <h2>CONNECT WITH US<a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a></h2>
            <h3>SING UP TO RECIEVE UPDATES</h3>
            <div class="input-btn">
              <input type="text" class="form-control-btn" placeholder="Your Email Address">
              <div class="input-group-btn"> </div>
            </div>
          </div>
        </div>
      
   
    </div>
    
    <div class="row">
      
        <div class="col-md-8 col-sm-6">
          <div class="report-potential">
            <p>To report potential policry viotions, fraidulent, or unehical behavior,please called 855-858-3344 or go to www.integraReport.com</p>
          </div>
        </div>
        <div class="col-md-4 col-sm-6">
          <div class="report-potential f-right">
            <p>REW MATERIAL, 20117 All rights reserved dizziden</p>
          </div>
        </div>
   
    </div>
  </div>
</div>
<div class="footer-menu">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="menu-bottem">
          <ul>
            <li><a href="#">PRODUCTS</a></li>
            <li><a href="#">SERVICRES & DELIVERY</a></li>
            <li><a href="#">TOOLS & RESOURCES</a></li>
            <li><a href="#">LOCATIONS</a></li>
			    <li><a href="#">ABOUT REW</a></li>
            <li><a href="#">CAREERS</a></li>
          </ul>
          <div class="rights-title">
            <p>website devloped and hosted by digital lagoon  </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--<script src="<?=get_stylesheet_directory_uri();?>/js/jquery.js"></script> 
<script src="<?=get_stylesheet_directory_uri();?>/js/bootstrap.min.js"></script>-->
</div>
<?php wp_footer(); ?>

</body>
</html>
